             function kembali(){
                $.mobile.changePage("#mainmenu", {transition: "slide", reverse: true});
            };
            function inbox(){
                $.mobile.changePage("#inbox", {transition: "slide", reverse: false});
                
            };
            function create(){
                $.mobile.changePage("#create", {transition: "none", reverse: false});
                
                
            };
            function group(){
                $.mobile.changePage("#group", {transition: "none", reverse: false});
            };
            function schedule(){
                $.mobile.changePage("#schedule", {transition: "none", reverse: false});
            };
            function twitter(){
                $.mobile.changePage("#twitter", {transition: "slide", reverse: false});
            };
            
            function about(){
                $.mobile.changePage("#about", {transition: "slide", reverse: false});
            };
            
            function help(){
                $.mobile.changePage("#help", {transition: "slide", reverse: false});
            };